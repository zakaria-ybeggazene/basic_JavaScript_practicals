const ball = { x : 0, y : 0, width: 20, height: 20, speed_x : 0, speed_y : 0, display : null };
const player1 = { score: 0, x : 0, y : 0, width: 20, height: 140, display: null };
const player2 = { score: 0, x : 0, y : 0, width: 20, height: 140, display: null };
const wall1 = { x : 0, y : 0, width: 1000, height : 20, display: null };
const wall2 = { x : 0, y : 0, width: 1000, height : 20, display: null };


function init_ball () {
    /* A COMPLÉTER */

};



/* A COMPLÉTER */
