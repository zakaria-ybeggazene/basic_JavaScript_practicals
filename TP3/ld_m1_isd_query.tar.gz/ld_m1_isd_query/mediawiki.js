/* Un objet singleton utilisé comme namespace ou 'package' */
var MediaWiki = {};


MediaWiki.ajax = function (method, url) {

    return new Promise ((resolve, reject) => {
        let xhr = new XMLHttpRequest();
        xhr.addEventListener("readystatechange",  function () {

            if (this.readyState == 4) {
                if (this.status == 200)
                    resolve(this.responseText);
                else
                    reject(this.status + " : " + this.responseText);
            }
        });

        xhr.open(method, url);

        xhr.setRequestHeader("Content-Type", "application/json; charset=UTF-8"); // type de retour
        xhr.setRequestHeader( 'Api-User-Agent', 'M1Info/1.0' ); //spécifique à Wikimedia

         xhr.send();
    })
};

/* fonction qui envoie uen requête AJAX à l'API Wikimedia. Le resultat est récupéré au format JSON
   et passé en argument à la fonction 'success' en cas de succès ou 'fail' en cas d'erreur.
*/

MediaWiki.query = function (params) {
    let paramString = "";

    for (let p in params) {
        /* on itère sur toutes les clés de 'params' (qui ne sont pas dans son prototype)
           pour construire la requête
        */
        if (params.hasOwnProperty (p)) {


            paramString += "&" + p + "=" + encodeURIComponent(params[p]);
        };

    };
    let url = "https://www.mediawiki.org/w/api.php?origin=*&format=json&formatversion=2"
        + paramString;


    /*** A COMPLÉTER ****/
    /* RENVOYER UNE PROMESSE QUI SE RÉSOUT SUR L'OBJET JSON CORRESPONDANT À L'URL CI-DESSUS,
       DÉCODÉ */

    return null; // <- REMPLACER
};


MediaWiki.getImageURL = function (title) {
   /*** A COMPLÉTER ****/
   /* APPELLE MediaWiki.query avec les bons paramètres */
   return null; // <- REMPLACER
};

/* Effectue une requête pour récupérer toutes les pages d'image ayant
 * un rapport avec la chaîne donnée.
*/

MediaWiki.searchImages = function (str) {
    /***** À COMPLÉTER *****/
    return null;
};
