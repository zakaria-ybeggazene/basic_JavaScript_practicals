window.addEventListener("load", function () {
    let search = document.getElementById("search");
    let searchButton = document.getElementById("searchButton");
    /**** À COMPLÉTER ****/


});
